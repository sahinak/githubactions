# Work with GitHub Actions
In this exercise we will create a simple GitHub Marketplace and use it to greet the create Test Automation University! 

## Steps:
1. **Navigate to Actions** <br>   
2. **Create a new Actions** <br>
3. **Trigger the Action manually** <br>
