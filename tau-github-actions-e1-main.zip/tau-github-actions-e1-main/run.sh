 #!/bin/bash         

echo "Hey, Automation Star!"
echo "My Name is John Doe and I work as an Test Automation Engineer. "

var1=${1:-not_set}

echo "${var1}"
